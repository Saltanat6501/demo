package kz.spring.projects.projoctSpringJva.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "t_instrument")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Instruments {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "instruments")
    private String instruments ;

}
