package kz.spring.projects.projoctSpringJva.controllers;


import kz.spring.projects.projoctSpringJva.model.*;
import kz.spring.projects.projoctSpringJva.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MainController {

    @Autowired
    private MusicalRepository musicalRepository;

    @Autowired
    private InstrumentRepository instrumentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BrandRepository brandRepository;








    @GetMapping(value = "/")
    public String indexPage(Model model){
        List<Musical> musicals = musicalRepository.findAll();
        model.addAttribute("clothing" , musicals);


        return "index";
    }



    @GetMapping(value = "/login")
    public String login(Model model){
        model.addAttribute("currentUser" , getCurrentUser());
        return "login";
    }




    @PostMapping(value = "/adduser")
    public String adduser(@RequestParam(name = "user_email")String email,
                          @RequestParam(name = "user_password")String password,
                          @RequestParam(name = "user_full_name")String name){
            Users users = new Users();
            users.setEmail(email);
            users.setPassword(password);
            users.setFullName(name);
            userRepository.save(users);

        return "redirect:/login";
    }



    @GetMapping(value = "/profile")
    @PreAuthorize("isAuthenticated()")
    public String profile(Model model){
        model.addAttribute("currentUser" , getCurrentUser());
        return "profile";
    }

    @GetMapping(value = "/adminpanel")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String admin(Model model){
        model.addAttribute("currentUser" , getCurrentUser());
        return "adminpanel";
    }

    @GetMapping(value = "/moderatorpanel")
    @PreAuthorize("hasAnyRole('ROLE_MODERATOR')")
    public String moderator(Model model){
        model.addAttribute("currentUser" , getCurrentUser());
        return "moderatorpanel";
    }

    @GetMapping(value = "/403")
    public String accessDeniedPage(Model model){
        model.addAttribute("currentUser" , getCurrentUser());
        return "403";
    }

    private Users getCurrentUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(!(authentication instanceof AnonymousAuthenticationToken)){
            Users currentUser = (Users) authentication.getPrincipal();
            return currentUser;
        }
        return null;
    }

    @GetMapping(value = "/addMusicalInstrument")
    public String ClothingAdd(Model model){
        List <Musical> musicals = musicalRepository.findAll();
        model.addAttribute("musical" , musicals);

        List <Instruments> instruments = instrumentRepository.findAll();
        model.addAttribute("instrumentss" , instruments);

        List <Brand> brands = brandRepository.findAll();
        model.addAttribute("brand" , brands);
        return "addMusicalInstrument";
    }

    @PostMapping(value = "/addMusicalInstrument")
    public String addPlayer(@RequestParam(name = "price")int price,
                            @RequestParam(name = "instr_id") Long instrId,
                            @RequestParam(name = "brand_id") Long brandId){
        Instruments instruments = instrumentRepository.findById(instrId).orElse(null);
        Brand brand = brandRepository.findById(brandId).orElse(null);

        if(instruments != null && brand != null ) {
            Musical musical = new Musical();
            musical.setPrice(price);
            musical.setBrand(brand);
            musical.setInstruments(instruments);
            musicalRepository.save(musical);
        }

            return "redirect:/addMusicalInstrument";
    }

    @GetMapping(value = "/setting")
    public String setting(Model model){
        List<Users> users = userRepository.findAll();
        model.addAttribute("user" , users);
        return "setting";
    }


    @GetMapping(value = "/details/{id}")
    public String details(@PathVariable(name = "id")Long id , Model model){
        Musical musical = musicalRepository.findById(id).orElse(null);
        model.addAttribute("musical" , musical);

        List <Instruments> instruments = instrumentRepository.findAll();
        model.addAttribute("instr" , instruments);

        List <Brand> brands = brandRepository.findAll();
        model.addAttribute("brand" , brands);


        return "Details";
    }

    @PostMapping(value = "/saveMusicalInstrument")
    public String savePlayer(@RequestParam(name = "id")Long id,
                             @RequestParam(name = "price")int price,
                             @RequestParam(name = "instr_id") Long instrId,
                             @RequestParam(name = "brand_id") Long brandId){
        Musical musical = musicalRepository.findById(id).orElse(null);
        Instruments instruments = instrumentRepository.findById(instrId).orElse(null);
        Brand brand = brandRepository.findById(brandId).orElse(null);
        if(musical != null && instruments != null && brand != null ) {
            musical.setInstruments(instruments);
            musical.setPrice(price);
            musical.setBrand(brand);
            musicalRepository.save(musical);
            return "redirect:/details/" + id;
        }
        return "redirect:/addMusicalInstrument";
    }

    @PostMapping(value = "/delete")
    public String deletePlayer(@RequestParam(name = "id")Long id){
        Musical musical = musicalRepository.findById(id).orElse(null);
        if(musical != null) {
            musicalRepository.delete(musical);
        }
        return "redirect:/addMusicalInstrument";
    }






    @GetMapping(value = "/detailsu/{id}")
    public String detailsu(@PathVariable(name = "id")Long id , Model model){
        Users users = userRepository.findById(id).orElse(null);
        model.addAttribute("user" , users);

        return "detailsu";
    }

    @PostMapping(value = "/saveUser")
    public String savePlayer(@RequestParam(name = "id")Long id,
                             @RequestParam(name = "email")String email,
                             @RequestParam(name = "full_name")String name){
        Users users = userRepository.findById(id).orElse(null);
        if(users != null) {
            users.setEmail(email);
            users.setFullName(name);
            userRepository.save(users);
            return "redirect:/detailsu/" + id;
        }
        return "redirect:/profile";
    }



    @PostMapping(value = "/deleteUser")
    public String deleteUser(@RequestParam(name = "id")Long id){
        Users users = userRepository.findById(id).orElse(null);
        if(users != null) {
            userRepository.delete(users);
        }
        return "redirect:/profile";
    }

    @GetMapping(value = "/players")
    public String players(Model model){
        List<Musical> musicals = musicalRepository.findAll();
        model.addAttribute("musical" , musicals);


        return "Players";
    }





}
