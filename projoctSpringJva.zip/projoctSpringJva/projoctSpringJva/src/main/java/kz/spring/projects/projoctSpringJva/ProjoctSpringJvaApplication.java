package kz.spring.projects.projoctSpringJva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjoctSpringJvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjoctSpringJvaApplication.class, args);
	}

}
