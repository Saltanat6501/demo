package kz.spring.projects.projoctSpringJva.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "t_musical")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Musical {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "price")
    private int price;

    @ManyToOne(fetch = FetchType.EAGER)
    private Instruments instruments;

    @ManyToOne(fetch = FetchType.EAGER)
    private Brand brand;



}
