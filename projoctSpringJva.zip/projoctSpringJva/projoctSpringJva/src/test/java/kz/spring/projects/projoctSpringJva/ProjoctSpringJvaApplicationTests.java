package kz.spring.projects.projoctSpringJva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjoctSpringJvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
